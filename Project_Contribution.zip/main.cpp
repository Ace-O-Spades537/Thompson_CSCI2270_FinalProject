
#include <iostream>
#include <string>
#include <unistd.h>
#include "GraphEvents.h"
#include "VisualGraph.h"

using namespace std;

int main()
{
    int a;
    int b;

    cout << string(50, '\n');

    cout << "Please enter a width of the Graph:";
    cin >> a;

    cout << string(50, '\n');

    cout << "Please enter a height of the Graph:";
    cin >> b;

    cout << string(50, '\n');

    cout << "Thank you initializing Graph";

    VisualGraph g(a, b);

    cout << string(50, '\n');

    string fileName;
    cout << "Please enter the name that you want the Graph data to be sent:";
    cin >> fileName;

    g.sendNodeStatus(fileName);

    cout << string(50, '\n');

    int command= 0;
    int originalX = a;

    int originalY = b;
    while(command != 6)
    {
        cout << "OPTIONS:" << endl;
        cout << "1. Change value at (x,y)" << endl;
        cout << "2. Change all values to neutral" << endl;
        cout << "3. Change all values to max" << endl;
        cout << "4. Create Raindrop Event and loop(Event algorithm not finished)" << endl;

        g.printNodeStatus();

        cout << endl;
        cin >> command;


        int x;
        int y;
        bool success = false;
        int newVal;
        Node* pointerNode = g.anchor;

        GraphEvents GE(&g, 1);
        GE.initializeBuffers();

        switch(command)
        {
            case 1:
                while(success != true)
                {
                    cout << "Enter X value:";
                    cin >> x;
                    cout << "Enter Y value;";
                    cin >> y;
                    cout << "What would you like to change it to? (0-255):";
                    cin >> newVal;
                    if(0 <= x && x <= originalX && 0 <= y && y <= originalY && 0 <= newVal  && newVal <= 255)
                    {

                        success = true;
                    }
                    else
                    {
                        cout<<"Not valid entries!"<<endl;
                    }
                }

                pointerNode = g.findNode(x,y);
                pointerNode->height = newVal;
                break;
            case 2:
                g.ChangeAllTo(0);
                break;
            case 3:
                g.ChangeAllTo(255);
                break;
            case 4:
                while(true)
                {
                    GE.update();
                    g.printNodeStatus();
                    sleep(1);
                    cout << string(50, '\n');

                }
        }

        cout << string(50, '\n');


    }


}
